--sorts pokemon moves by contest moves
select m_id, m_name from moves where m_contest='Cool';

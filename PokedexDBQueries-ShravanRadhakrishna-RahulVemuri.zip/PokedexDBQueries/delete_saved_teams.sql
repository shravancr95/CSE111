--Deletes a team where a certain condition is met, in this case it's if the first pokemon is a blastoise
delete from saved_teams where pkmn1 = 'Blastoise' ;
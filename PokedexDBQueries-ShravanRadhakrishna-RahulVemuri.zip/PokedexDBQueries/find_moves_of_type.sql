--allows users to find normal moves
select m_name from moves where m_type='normal';

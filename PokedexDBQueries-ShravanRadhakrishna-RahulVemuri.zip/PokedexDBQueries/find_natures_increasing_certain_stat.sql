--allows to find a nature that increases a certain stat
select nature from natures where increase= 'Special Attack';

--dual types
select name, type1, type2 from pokemon where type2 <> 'NULL';
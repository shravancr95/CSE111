--select pokemon who are specialized to be special sweepers
select * from movesets where spd_ev = 252 and spatk_ev = 252;
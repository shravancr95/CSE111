--orders pokemon in alphabetical order
select * from pokemon 
order by name asc;
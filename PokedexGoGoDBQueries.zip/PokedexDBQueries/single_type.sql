--select single type pokemon only
select name from pokemon where type2='NULL';



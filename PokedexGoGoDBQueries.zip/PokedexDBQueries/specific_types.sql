--selects pokemon of type that user specifies, will be much more versatile with java
select * from Pokemon where type1='grass' or type2='grass';
